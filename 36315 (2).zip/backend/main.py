from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import sqlite3

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------- DATABASE ----------
conn = sqlite3.connect("users.db", check_same_thread=False)
cur = conn.cursor()

cur.execute("""
CREATE TABLE IF NOT EXISTS users(
id INTEGER PRIMARY KEY AUTOINCREMENT,
name TEXT,
email TEXT,
password TEXT
)
""")
conn.commit()

# ---------- MODELS ----------
class User(BaseModel):
    name:str
    email:str
    password:str

class Usage(BaseModel):
    apps:list
    night_usage:float

# ---------- ROUTES ----------
@app.get("/")
def home():
    return {"msg":"RadiationGuardian backend running"}

@app.post("/signup")
def signup(user:User):
    cur.execute("INSERT INTO users(name,email,password) VALUES(?,?,?)",
                (user.name,user.email,user.password))
    conn.commit()
    return {"msg":"user created"}

@app.post("/login")
def login(user:User):
    # check if user exists
    cur.execute("SELECT * FROM users WHERE email=? AND password=?",
                (user.email,user.password))
    data = cur.fetchone()

    # if not exists → auto create user (hackathon mode)
    if not data:
        cur.execute("INSERT INTO users(name,email,password) VALUES(?,?,?)",
                    (user.name,user.email,user.password))
        conn.commit()
        return {"msg":"success","name":user.name}

    return {"msg":"success","name":data[1]}


@app.post("/analyze")
def analyze(data:Usage):
    total_hours = sum(a["hours"] for a in data.apps)
    social = sum(a["hours"] for a in data.apps if a["category"]=="social")

    score = total_hours*8 + data.night_usage*20 + social*5
    if score>100: score=100

    risk="LOW"
    if score>40: risk="MEDIUM"
    if score>70: risk="HIGH"

    blocked=[]
    for a in data.apps:
        if a["category"] not in ["emergency","payments"] and a["hours"]>1.5 and score>50:
            blocked.append(a["name"])

    return {
        "score":round(score,2),
        "risk":risk,
        "blocked_apps":blocked
    }
